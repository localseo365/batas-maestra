<?php
define('URL', 'https://batasmaestra.pages.dev/');
?>